import React from 'react';
import {Progress} from 'semantic-ui-react';

const progressBar = ()=> {
    // const {funded, goal} = this.props;
    // console.log(funded, goal)
    return <p>progress</p>
    // const percent = Math.round((funded / goal) *100)
    // if(percent > 100){
    //     return <Progress progress success percent={percent} />
    // } else if (percent < 100 && percent > 80){
    //     return <Progress progress warning percent={percent} />
    // } else if (percent < 80) {
    //     return <Progress progress error percent={percent} />
    // }
}

export default progressBar;

   

