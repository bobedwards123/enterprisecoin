import React from 'react';
import {RadialChart} from 'react-vis';
export default class PieChart extends React.Component {
    render(){
        return (
            <RadialChart />
        )
    }
}